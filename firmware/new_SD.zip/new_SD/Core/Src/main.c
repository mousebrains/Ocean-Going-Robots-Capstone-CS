/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2021 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "fatfs.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <string.h>
#include <time.h>
#include <stdlib.h> // rand
#include <ctype.h>  // isdigit
#include <stdio.h>
#include <time.h>
//#include "retarget.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
SD_HandleTypeDef hsd1;

/* USER CODE BEGIN PV */
uint8_t mounted = 0;
uint8_t allGood = 0;
uint8_t data[6] = {100,20,30,40,50,60};

float bigData[] = {
		0.0675413818764984,
		0.0883100876973178,
		0.1089160335478132,
		0.1292981921108044,
		0.1493960846752786,
		0.1691499632500713,
		0.1885009902964675,
		0.2073914155437786,
		0.2257647493628678,
		0.2435659321850101,
		0.2607414994673478,
		0.277239741721436,
		0.2930108591379846,
		0.3080071103587636,
		0.3221829549657497,
		0.3354951892778363,
		0.347903075066769,
		0.3593684608263695,
		0.3698558952523831,
		0.3793327326145223,
		0.3877692297272756,
		0.3951386342517549,
		0.4014172640872681,
		0.4065845776382288,
		0.4106232347694553,
		0.4135191482907682,
		0.4152615258399514,
		0.4158429020615677,
		0.4152591610077096,
		0.4135095487154081,
		0.410596675944099,
		0.4065265110851307,
		0.4013083632837039,
		0.3949548558418281,
		0.3874818899987459,
		0.378908599212735,
		0.3692572940952143,
		0.3585533981745306,
		0.3468253746926628,
		0.3341046446632369,
		0.3204254964436751,
		0.3058249870978993,
		0.2903428358487608,
		0.2740213099411438,
		0.2569051032575294,
		0.2390412080475658,
		0.2204787801518636,
		0.2012689981177997,
		0.1814649166214485,
		0.1611213146249278,
		0.140294538712295,
		0.119042342059766,
		0.0974237195072617,
		0.0754987392082451,
		0.0533283713433601,
		0.0309743143905735,
		0.0084988194502863,
		-0.014035486871722,
		-0.0365657805177345,
		-0.0590292184605484,
		-0.0813631171075017,
		-0.1035051301198814,
		-0.1253934251442277,
		-0.1469668589561562,
		-0.1681651505227329,
		-0.1889290514962974,
		-0.2092005136607591,
		-0.2289228528608279,
		-0.2480409089554158,
		-0.2665012013483661,
		-0.2842520796628951,
		-0.3012438691404515,
		-0.3174290103601745,
		-0.3327621928917063,
		-0.3472004825116748,
		-0.3607034416327461,
		-0.373233242613653,
		-0.3847547736389474,
		-0.3952357368784608,
		-0.4046467386583489,
		-0.4129613713983004,
		-0.4201562870927185,
		-0.4262112621375566,
		-0.4311092533288467,
		-0.4348364448837374,
		-0.4373822863600194,
		-0.4387395213755989,
		-0.4389042070550408,
		-0.4378757241562018,
		-0.4356567778558894,
		-0.4322533891994796,
		-0.4276748772453489,
		-0.4219338319607812,
		-0.4150460779516456,
		-0.4070306291335072,
		-0.397909634476885,
		-0.3877083149840329,
		-0.3764548920788197,
		-0.3641805076149835,
		-0.3509191357311276,
		-0.3367074868032942,
		-0.3215849037677063,
		-0.3055932511072705,
		-0.2887767968155981,
		-0.2711820876716274,
		-0.2528578181763137,
		-0.2338546935202505,
		-0.2142252869675173,
		-0.1940238920563525,
		-0.1733063700315143,
		-0.1521299929362715,
		-0.1305532828039059,
		-0.1086358473993003,
		-0.0864382129706962,
		-0.0640216544799075,
		-0.0414480237862246,
		-0.0187795762648799,
		0.0039212036547372,
		0.0265917775429286,
		0.0491697281257557,
		0.0715929340531732,
		0.0937997437901087,
		0.1157291481437263,
		0.1373209509438242,
		0.158515937398369,
		0.1792560396524709,
		0.1994844990868091,
		0.2191460249003855,
		0.2381869485327055,
		0.2565553734918754,
		0.2742013201677122,
		0.2910768652227538,
		0.3071362751689523,
		0.3223361337538488,
		0.3366354627970603,
		0.3499958361359919,
		0.3623814863586805,
		0.3737594040216416,
		0.3840994290713178,
		0.3933743342093679,
		0.4015598999643333,
		0.4086349812552404,
		0.4145815652563417,
		0.4193848203963943,
		0.4230331363505679,
		0.4255181549082076,
		0.4268347916251655,
		0.4269812481951913,
		0.4259590155008929,
		0.4237728673309298,
		0.4204308447763558,
		0.4159442313452758,
		0.4103275188611963,
		0.4035983642364902,
		0.3957775372382844,
		0.3868888593896428,
		0.376959134174183,
		0.3660180687370591,
		0.354098187299616,
		0.3412347365287776,
		0.3274655831254139,
		0.3128311039183998,
		0.2973740687728052,
		0.281139516641571,
		0.2641746251100703,
		0.2465285738020271,
		0.2282524020334423,
		0.2093988611181848,
		0.1900222617449319,
		0.1701783168599649,
		0.1499239805039845,
		0.1293172830635092,
		0.108417163408626,
		0.0872832983986372,
		0.065975930245717,
		0.0445556922337965,
		0.0230834332956674,
		0.0016200419555987,
		-0.0197737298523057,
		-0.0410374425783692,
		-0.0621111439525308,
		-0.0829355424703359,
		-0.103452178962424,
		-0.1236035957447179,
		-0.1433335028523203,
		-0.1625869408674677,
		-0.1813104398606387,
		-0.1994521739740754,
		-0.2169621111885697,
		-0.2337921578272681,
		-0.2498962973645842,
		-0.2652307231238528,
		-0.2797539644642203,
		-0.2934270060753948,
		-0.3062134000181138,
		-0.318079370168593,
		-0.3289939087467322,
		-0.3389288646303355,
		-0.3478590231811173,
		-0.3557621773326171,
		-0.3626191897153905,
		-0.3684140456208307,
		-0.3731338966316701,
		-0.3767690947745355,
		-0.3793132170777971,
		-0.3807630804462946,
		-0.3811187467932795,
		-0.380383518398926,
		-0.3785639234940878,
		-0.3756696920973474,
		-0.3717137221629275,
		-0.3667120361264525,
		-0.3606837279649023,
		-0.3536509009162176,
		-0.3456385960328677,
		-0.3366747117721404,
		-0.3267899148539193,
		-0.3160175426441535,
		-0.3043934973490198,
		-0.291956132330873,
		-0.278746130882352,
		-0.2648063778193667,
		-0.2501818242771688,
		-0.2349193461160126,
		-0.2190675963642095,
		-0.2026768521464257,
		-0.1857988565638536,
		-0.1684866560103553,
		-0.1507944334247628,
		-0.1327773379940834,
		-0.1144913118355432,
		-0.0959929141968308,
		-0.0773391437239655,
		-0.0585872593543437,
		-0.0397946003992565,
		-0.0210184063848722,
		-0.0023156372238922,
		0.0162572057086275,
		0.0346442570223579,
		0.0527904627108955,
		0.070641370785256,
		0.0881455091974754,
		0.1052596598450242,
		0.1219426875878563,
		0.1381549667927862,
		0.153858444811343,
		0.1690167006559236,
		0.1835949989355591,
		0.1975603391247936,
		0.210881500250064,
		0.2235290810877976,
		0.2354755359769441,
		0.2466952063560057,
		0.2571643481408042,
		0.266861155064146,
		0.2757657781023684};
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_SDMMC1_SD_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
FATFS myFatFS;
FIL myFile;
UINT myBytes; //# bytes written if error
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_SDMMC1_SD_Init();
  MX_FATFS_Init();
  /* USER CODE BEGIN 2 */
//=======================================================================

clock_t start clock();
if(f_mount(&myFatFS,SDPath, 1) == FR_OK) // connected successfully
{
	mounted = 1;
	HAL_GPIO_TogglePin(GPIOB,GPIO_PIN_7); // turn on blue LED

	char myFileName[] = "NUCLEOTEST2.TXT\0"; // works better with upper case?
//	char myFileName[] = "1234567890.CSV\0"; // works better with upper case?
//	char myFileName[] = "1235.CSV\0"; // works better with upper case?
	if(f_open(&myFile, myFileName, FA_WRITE | FA_CREATE_ALWAYS) == FR_OK){
		HAL_GPIO_TogglePin(GPIOB,GPIO_PIN_14); // flash red LED
//		uint8_t myData[] = "Long filenames are so cool\r1,2,3,4,5\n6,7,8,9,10\0"; //
		char myData[] = "pee,pee\n\0"; //
		if(f_write(&myFile, myData, sizeof(myData), &myBytes) == FR_OK){
//		if(f_write(fp, buff, btw, bw))
//		if(f_write(&myFile, bigData, 16, &myBytes) == FR_OK){
			HAL_GPIO_TogglePin(GPIOB,GPIO_PIN_7); //flash blue LED
			allGood = 1;
		}
		f_close(&myFile);
	}
}
clock_t end clock();



  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
	  if (mounted)
		  HAL_GPIO_TogglePin(GPIOB,GPIO_PIN_7); //flash blue LED
	  else
		  HAL_GPIO_TogglePin(GPIOB,GPIO_PIN_14);
	  if(allGood)
		  HAL_Delay(200);
	  else
		  HAL_Delay(1000);
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Configure the main internal regulator output voltage
  */
  if (HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_MSI;
  RCC_OscInitStruct.MSIState = RCC_MSI_ON;
  RCC_OscInitStruct.MSICalibrationValue = 0;
  RCC_OscInitStruct.MSIClockRange = RCC_MSIRANGE_6;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_MSI;
  RCC_OscInitStruct.PLL.PLLM = 1;
  RCC_OscInitStruct.PLL.PLLN = 16;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV16;
  RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV2;
  RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_SDMMC1;
  PeriphClkInit.Sdmmc1ClockSelection = RCC_SDMMC1CLKSOURCE_PLLP;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief SDMMC1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SDMMC1_SD_Init(void)
{

  /* USER CODE BEGIN SDMMC1_Init 0 */

  /* USER CODE END SDMMC1_Init 0 */

  /* USER CODE BEGIN SDMMC1_Init 1 */

  /* USER CODE END SDMMC1_Init 1 */
  hsd1.Instance = SDMMC1;
  hsd1.Init.ClockEdge = SDMMC_CLOCK_EDGE_RISING;
  hsd1.Init.ClockPowerSave = SDMMC_CLOCK_POWER_SAVE_DISABLE;
  hsd1.Init.BusWide = SDMMC_BUS_WIDE_1B;
  hsd1.Init.HardwareFlowControl = SDMMC_HARDWARE_FLOW_CONTROL_DISABLE;
  hsd1.Init.ClockDiv = 4;
  hsd1.Init.Transceiver = SDMMC_TRANSCEIVER_DISABLE;
  /* USER CODE BEGIN SDMMC1_Init 2 */

  /* USER CODE END SDMMC1_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOG_CLK_ENABLE();
  HAL_PWREx_EnableVddIO2();
  __HAL_RCC_GPIOA_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, LD3_Pin|LD2_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(USB_PowerSwitchOn_GPIO_Port, USB_PowerSwitchOn_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : B1_Pin */
  GPIO_InitStruct.Pin = B1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(B1_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : LD3_Pin LD2_Pin */
  GPIO_InitStruct.Pin = LD3_Pin|LD2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pins : STLK_RX_Pin STLK_TX_Pin */
  GPIO_InitStruct.Pin = STLK_RX_Pin|STLK_TX_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  GPIO_InitStruct.Alternate = GPIO_AF7_USART3;
  HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

  /*Configure GPIO pin : USB_PowerSwitchOn_Pin */
  GPIO_InitStruct.Pin = USB_PowerSwitchOn_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(USB_PowerSwitchOn_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : PG6 */
  GPIO_InitStruct.Pin = GPIO_PIN_6;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(GPIOG, &GPIO_InitStruct);

  /*Configure GPIO pins : STLINK_TX_Pin STLINK_RX_Pin */
  GPIO_InitStruct.Pin = STLINK_TX_Pin|STLINK_RX_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  GPIO_InitStruct.Alternate = GPIO_AF8_LPUART1;
  HAL_GPIO_Init(GPIOG, &GPIO_InitStruct);

  /*Configure GPIO pins : USB_SOF_Pin USB_ID_Pin USB_DM_Pin USB_DP_Pin */
  GPIO_InitStruct.Pin = USB_SOF_Pin|USB_ID_Pin|USB_DM_Pin|USB_DP_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  GPIO_InitStruct.Alternate = GPIO_AF10_OTG_FS;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
